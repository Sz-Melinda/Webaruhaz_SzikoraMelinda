
$(function () {

    const kosar = new Kosar();

});
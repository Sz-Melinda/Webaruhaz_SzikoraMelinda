
class Kosar {

    constructor() {

        this.kosarTomb = [];

        this.kosarElem = $("#kosarTartalom");

        // LocalStorage-ból kiolvassuk az adatokat
        this.kosarTomb = JSON.parse(localStorage.getItem("kosarTomb"));
        console.log(this.kosarTomb);
        this.kosarMegjelenit();

        this.kosarElem.on("click", ".torol", (event) => {

            let id = $(event.target).attr("id");
            this.kosarTomb.splice(id, 1);

            localStorage.setItem("kosarTomb", JSON.stringify(this.kosarTomb));

            this.kosarMegjelenit();
        });
    }

    elemKosarbaHelyezes(elem) {

        this.kosarTomb.push(elem);

        // LocalStorage-ba lementjük a kosár tartalmát 
        localStorage.setItem("kosarTomb", JSON.stringify(this.kosarTomb));

        this.kosarMegjelenit();
    }

    kosarMegjelenit() {

        this.kosarElem.empty();
        $("#osszAr").empty();

        let osszeg = 0;

        this.kosarElem.append("<table>");

        for(let i = 0; i < this.kosarTomb.length; i++) {

            $("table").append("<tr> <th>" + this.kosarTomb[i]['nev'] + "</th> <th>" + this.kosarTomb[i]['ar'] + " Ft</th> <th> <button class='torol' id='"+ i +"'> X </button> </th> </tr>");

            osszeg += this.kosarTomb[i]['ar'];
        }

        this.kosarElem.append("</table>");
        $("#osszAr").append(osszeg + " Ft");

    }

}